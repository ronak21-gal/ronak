<center>
<footer>
<div class="container">
<div class="row">
<div class="col-sm-12 col-xs-12 col-md-4 col-lg-4">
<p style="color:#bdc3c7">Developed by Ronak gal</p><br>
<p style="color:#bdc3c7">Ronakgal1996@gmail.com</p>
</div>
<div class="col-sm-12 col-xs-12 col-md-4 col-lg-4">
<p style="color:#bdc3c7">Copyright &copy;  E-Store. All Rights Reserved </p><br>
<p style="color:#bdc3c7">Contact Us: +91 8450934370</p>
</div>
<div class="col-sm-12 col-xs-12 col-md-4 col-lg-4">
<p style="color:#bdc3c7">About us</p><br>
<a href="contact.php" style="text-decoration: none;color:#bdc3c7"><p>Contact form</p></a>
</div>
</div>
</div>
</footer></center>