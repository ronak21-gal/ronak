<?php
session_start();
require 'includes/common.php';
if (!isset($_SESSION['email'])) {
    header('location: index.php');
}
?>
<?php
include 'form_process.php';
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta name="viewport" content="width = device-width, initial-scale = 1">
        <title>Success | Life Style Store</title>
        <link href="css/bootstrap.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
        <style>
        	.class{
        		width:400px;
        	}
        </style>
    </head>
    <body>
        <?php include 'includes/header.php'; ?>
        <div class="container class">
        <h1>Feedback Form</h1>
        <center><form action="<?= htmlspecialchars($_SERVER["PHP_SELF"]) ?>" method="POST">
<div class="form-group">
Name:<input type="text" class="form-control" placeholder="Enter your name" name="name" value="<?= $name ?>" tabindex="1" autofocus><span class="red"><?= $name_error ?></span></div>

<div class="form-group">
Email:<input type="email" class="form-control" placeholder="Enter your Email address" name="email" value="<?= $email ?>" tabindex="2"><span class="red"><?= $email_error ?></span></div>

<div class="form-group">
Contact no:<input type="text" class="form-control" placeholder="Enter your contact" name="phone" value="<?= $phone ?>" tabindex="3"><span class="red"><?= $phone_error ?></span></div>

<div class="form-group">
Comment:<textarea type="textarea" class="form-control" placeholder="Add your comment.." name="comment"></textarea>
</div><br>

<button class="btn btn-primary btn-md" name="submit" type="submit" id="contact-submit" data-submit="...Sending">submit</button></div>
<div class="success"><?= $success ?></div>
        

        </form><br><br><br><br><br><br><br><br>
        <?php include("includes/footer.php");
        ?>
    </body>
</html>