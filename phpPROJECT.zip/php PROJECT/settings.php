<?php
session_start();
require("includes/common.php");
if (!isset($_SESSION['email'])) {
    header('location: index.php');
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Settings | E-Store</title>
        <link href="css/bootstrap.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
        <script src="js/jquery.js"></script>
        <script src="js/bootstrap.min.js"></script>
    </head>
    <body>
        <?php include 'includes/header.php'; ?>
        <div class="container-fluid" id="content">
            <div class="row">
                <div class="col-lg-4 col-lg-offset-4" id="settings-container">
                   <center><u> <h2>Change Password</h2></u><br>
                    <form action="settings.php" method="POST">
                        <div class="form-group">
                            Old password<input type="password" class="form-control" name="old-password"  placeholder="Old Password" required = "true">
                        </div>
                        <div class="form-group">
                            New password<input type="password" class="form-control" name="password" placeholder="New Password" required = "true">
                        </div>
                        <div class="form-group">
                            Re-enter new password<input type="password" class="form-control" name="password1"  placeholder="Re-type New Password" required = "true">
                        </div><br>
                        <button type="submit" class="btn btn-primary" name="change">Change</button>
                       <?php
                      if(isset($_POST['change']))
                    
                       {
                    $old_pass = $_POST['old-password'];
                    $old_pass = mysqli_real_escape_string($con, $old_pass);
                    $old_pass = MD5($old_pass);

                    $new_pass = $_POST['password'];
                    $new_pass = mysqli_real_escape_string($con, $new_pass);
                     $new_pass = MD5($new_pass);

                     $new_pass1 = $_POST['password1'];
                     $new_pass1 = mysqli_real_escape_string($con, $new_pass1);
                       $new_pass1 = MD5($new_pass1);

                     $query = "SELECT email, password FROM users WHERE email ='" . $_SESSION['email'] . "'";
                    $query_run=mysqli_query($con,$query);
                      $row = mysqli_fetch_array($query_run);
                      $orig_pass = $row['password'];

                   if ($new_pass != $new_pass1) 
                   {
                    echo '<script type="text/javascript"> alert("Password dont match") </script>';
                   }else 
                   if ($old_pass == $orig_pass) 
                   {
        $query = "UPDATE  users SET password = '" . $new_pass . "' WHERE email = '" . $_SESSION['email'] . "'";
        mysqli_query($con, $query) or die($mysqli_error($con));
        echo '<script type="text/javascript"> alert("Password updated") </script>';
    }else
    {
        echo '<script type="text/javascript"> alert("Wrong old password") </script>';
    }
}
                    ?>
                    </form>
                </div>
            </div>
        </div>
        <?php include("includes/footer.php"); ?>
    </body>
</html>